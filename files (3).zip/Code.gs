/**
 * نظام رصد الحضور اليومي - معهد العلوم الإسلامية بعبري
 * يعمل على Google Apps Script ويخزّن البيانات في جدول Google Sheets المرتبط به.
 *
 * خطوات الإعداد (مرة واحدة):
 * 1) اكتب أدناه الرقم السري الذي تريده لمدير النظام (8 أحرف على الأقل).
 * 2) من أعلى المحرر اختر الدالة setupSystem ثم اضغط "تشغيل" ووافق على الأذونات.
 * 3) بعد نجاح التشغيل امسح الرقم من السطر أدناه (اتركه نصًا فارغًا).
 * 4) انشر النظام: نشر > نشر جديد > تطبيق ويب (انظر ملف التعليمات).
 * التقارير: ورقتا "تقرير الطلبة" و"تقرير الشعب" تُنشآن تلقائيًا وتتحدثان مع كل رصد.
 * بعد إضافة طلاب أو شعب جديدة شغّل buildReports من قائمة "نظام الحضور" في الجدول.
 */
var INITIAL_ADMIN_PASSWORD = 'غيّر-هذا-الرقم';

var SESSION_SECONDS = 21600;
var P1 = 6; // رقم العمود الأول للحصص (F)
var LOW_ATTENDANCE = 0.8; // النسب الأقل من هذا الحد تظهر باللون الأحمر في التقارير (عدّله كما تشاء)
var STAT = {present: 'حاضر', absent: 'غائب', late: 'متأخر', excused: 'بعذر'};
var STAT_REV = {'حاضر': 'present', 'غائب': 'absent', 'متأخر': 'late', 'بعذر': 'excused'};
var ADMIN_ONLY = ['clear', 'addStudent', 'delStudent', 'teachers', 'addTeacher', 'resetTeacher', 'delTeacher', 'adminPw', 'drive', 'dailyReport'];
var WRITES = ['sync', 'cell', 'bulk', 'clear', 'addStudent', 'delStudent', 'addTeacher', 'resetTeacher', 'delTeacher', 'adminPw'];

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('رصد الحضور اليومي - معهد العلوم الإسلامية بعبري')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/* واجهة JSON لتطبيق الجوال الذي يعمل بدون إنترنت (PWA) — نص عادي لتفادي طلبات CORS المسبقة */
function doPost(e) {
  var out;
  try { out = api(JSON.parse(e.postData.contents)); }
  catch (err) { out = {ok: false, err: 'طلب غير صالح'}; }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------- الإعداد ---------- */
function setupSystem() {
  var pw = INITIAL_ADMIN_PASSWORD;
  if (!pw || pw.length < 8 || pw === 'غيّر-هذا-الرقم') {
    throw new Error('عدّل INITIAL_ADMIN_PASSWORD في أعلى الملف (8 أحرف على الأقل) ثم أعد التشغيل.');
  }
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  function mk(name, head) {
    var s = ss.getSheetByName(name) || ss.insertSheet(name);
    if (s.getLastRow() === 0) {
      s.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold');
      s.setFrozenRows(1);
    }
    return s;
  }
  var cl = mk('Classes', ['id', 'الشعبة']);
  var st = mk('Students', ['id', 'الشعبة', 'اسم الطالب', 'ملاحظة']);
  var us = mk('Users', ['username', 'الاسم', 'salt', 'hash', 'role']);
  var at = mk('Attendance', ['key', 'التاريخ', 'الشعبة', 'الطالب', 'sid', 'ح1', 'ح2', 'ح3', 'ح4', 'ح5', 'ح6', 'ح7', 'ح8', 'بواسطة', 'آخر تحديث']);
  cl.getRange('A:B').setNumberFormat('@');
  st.getRange('A:D').setNumberFormat('@');
  us.getRange('A:E').setNumberFormat('@');
  at.getRange('A:E').setNumberFormat('@');
  if (cl.getLastRow() < 2) {
    var cr = SEED.classes.map(function (c) { return [c.id, c.name]; });
    cl.getRange(2, 1, cr.length, 2).setValues(cr);
    var sr = [];
    SEED.classes.forEach(function (c) {
      c.students.forEach(function (s) { sr.push([s.id, c.name, s.name, s.note || '']); });
    });
    st.getRange(2, 1, sr.length, 4).setValues(sr);
  }
  if (us.getLastRow() < 2) {
    var salt = Utilities.getUuid();
    us.getRange(2, 1, 1, 5).setValues([['admin', 'مدير النظام', salt, hashPw_(pw, salt), 'admin']]);
  }
  buildReports();
  buildDailyReport();
  Logger.log('تم الإعداد. امسح الرقم السري من INITIAL_ADMIN_PASSWORD الآن ثم انشر التطبيق.');
}

/* لاستعادة رقم المدير: اكتب رقمًا جديدًا في INITIAL_ADMIN_PASSWORD ثم شغّل هذه الدالة */
function resetAdminPassword() {
  var pw = INITIAL_ADMIN_PASSWORD;
  if (!pw || pw.length < 8 || pw === 'غيّر-هذا-الرقم') throw new Error('اكتب رقمًا من 8 أحرف على الأقل في INITIAL_ADMIN_PASSWORD.');
  var u = findUser_('admin');
  if (!u) throw new Error('شغّل setupSystem أولاً.');
  setPassword_(u.row, pw);
  Logger.log('تم تغيير رقم المدير. امسح الرقم من الملف الآن.');
}

/* ---------- أدوات ---------- */
function sh_(n) {
  var s = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(n);
  if (!s) throw new Error('لم يتم الإعداد بعد: شغّل setupSystem أولاً.');
  return s;
}
function readRows_(sheet, n) {
  var c = sheet.getLastRow() - 1;
  return c < 1 ? [] : sheet.getRange(2, 1, c, n).getValues();
}
function colL_(n) {
  var s = '';
  while (n > 0) { var m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}
function hashPw_(pw, salt) {
  var h = salt + '|' + pw;
  for (var i = 0; i < 1000; i++) {
    h = Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h, Utilities.Charset.UTF_8));
  }
  return h;
}
function setPassword_(row, pw) {
  var salt = Utilities.getUuid();
  sh_('Users').getRange(row, 3, 1, 2).setValues([[salt, hashPw_(pw, salt)]]);
}
function findUser_(u) {
  var rows = readRows_(sh_('Users'), 5);
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][0]).toLowerCase() === u) {
      return {row: i + 2, u: String(rows[i][0]), name: String(rows[i][1]), salt: String(rows[i][2]), hash: String(rows[i][3]), role: String(rows[i][4])};
    }
  }
  return null;
}
function teachers_() {
  return readRows_(sh_('Users'), 5)
    .filter(function (r) { return r[4] === 'teacher'; })
    .map(function (r) { return {u: String(r[0]), name: String(r[1])}; });
}
function roster_() {
  var csh = sh_('Classes'), ssh = sh_('Students');
  var classes = [], byName = {}, newCls = [];
  readRows_(csh, 2).forEach(function (r) {
    if (r[0] && r[1]) { classes.push({id: String(r[0]), name: String(r[1])}); byName[String(r[1]).trim()] = String(r[0]); }
  });
  var students = [];
  readRows_(ssh, 4).forEach(function (r, i) {
    var name = String(r[2]).trim(), cn = String(r[1]).trim();
    if (!name || !cn) return;
    if (!byName[cn]) {
      var cid = 'c' + Utilities.getUuid().slice(0, 6);
      byName[cn] = cid; classes.push({id: cid, name: cn}); newCls.push([cid, cn]);
    }
    var id = String(r[0]).trim();
    if (!id) { id = 's' + Utilities.getUuid().slice(0, 8); ssh.getRange(i + 2, 1).setValue(id); }
    students.push({id: id, cls: byName[cn], name: name, note: String(r[3] || '')});
  });
  if (newCls.length) csh.getRange(csh.getLastRow() + 1, 1, newCls.length, 2).setValues(newCls);
  return {classes: classes, students: students};
}
function fmtDate_(v) {
  return v instanceof Date ? Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd') : String(v);
}

/* ---------- الدخول والجلسات ---------- */
function login_(p) {
  var role = p.role === 'admin' ? 'admin' : 'teacher';
  var u = role === 'admin' ? 'admin' : String(p.username || '').trim().toLowerCase();
  var pw = String(p.password || '');
  if (!u || !pw) return {ok: false, err: 'أدخل البيانات كاملة'};
  var cache = CacheService.getScriptCache(), fk = 'f_' + u.slice(0, 60);
  var fails = Number(cache.get(fk) || 0);
  if (fails >= 5) return {ok: false, err: 'محاولات خاطئة كثيرة، انتظر 15 دقيقة ثم حاول مجددًا'};
  var user = findUser_(u);
  if (!user || user.role !== role || hashPw_(pw, user.salt) !== user.hash) {
    cache.put(fk, String(fails + 1), 900);
    return {ok: false, err: 'اسم المستخدم أو الرقم السري غير صحيح'};
  }
  cache.remove(fk);
  var token = Utilities.getUuid() + Utilities.getUuid().replace(/-/g, '');
  cache.put('t_' + token, JSON.stringify({u: user.u, name: user.name, role: user.role}), SESSION_SECONDS);
  return {ok: true, token: token, name: user.name, role: user.role};
}
function session_(t) {
  if (!t) return null;
  var s = CacheService.getScriptCache().get('t_' + t);
  return s ? JSON.parse(s) : null;
}

/* ---------- نقطة الدخول الوحيدة للواجهة ---------- */
function api(req) {
  try {
    var a = req.action, p = req.p || {};
    if (a === 'login') return login_(p);
    if (a === 'ping') return {ok: true, setup: !!SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Users')};
    var s = session_(req.token);
    if (!s) return {ok: false, auth: true, err: 'انتهت الجلسة، سجّل الدخول من جديد'};
    if (ADMIN_ONLY.indexOf(a) >= 0 && s.role !== 'admin') return {ok: false, err: 'هذه العملية للمدير فقط'};
    var write = WRITES.indexOf(a) >= 0, lock = LockService.getScriptLock();
    if (write) lock.waitLock(20000);
    try { return handle_(a, p, s); } finally { if (write) lock.releaseLock(); }
  } catch (e) {
    return {ok: false, err: String((e && e.message) || e)};
  }
}

function handle_(a, p, s) {
  var at, rm, i, rows, rl, list;
  switch (a) {
    case 'load': {
      var R = roster_();
      var out = {ok: true, classes: R.classes, students: R.students};
      if (s.role === 'admin') out.teachers = teachers_();
      return out;
    }
    case 'att':
      return {ok: true, rows: attFor_(p.cls)};
    case 'cell':
      rm = ensureRows_(p.cls, p.date);
      i = Number(p.i);
      if (!rm.map[p.sid] || !(i >= 0 && i < 8)) throw new Error('بيانات غير صالحة');
      at = sh_('Attendance');
      at.getRange(rm.map[p.sid], P1 + i).setValue(STAT[p.v] || '');
      stamp_(at, [rm.map[p.sid]], s.name);
      return {ok: true};
    case 'bulk':
      rm = ensureRows_(p.cls, p.date);
      i = Number(p.i);
      if (!(i >= -1 && i < 8)) throw new Error('بيانات غير صالحة');
      at = sh_('Attendance');
      rl = rm.rows.map(function (r) { return i < 0 ? colL_(P1) + r + ':' + colL_(P1 + 7) + r : colL_(P1 + i) + r; });
      at.getRangeList(rl).setValue(STAT[p.v] || '');
      stamp_(at, rm.rows, s.name);
      return {ok: true};
    case 'clear':
      rm = ensureRows_(p.cls, p.date);
      at = sh_('Attendance');
      rl = rm.rows.map(function (r) { return colL_(P1) + r + ':' + colL_(P1 + 7) + r; });
      at.getRangeList(rl).clearContent();
      stamp_(at, rm.rows, s.name);
      return {ok: true};
    case 'addStudent': {
      var R2 = roster_();
      var c = R2.classes.filter(function (x) { return x.id === p.cls; })[0];
      var name = String(p.name || '').trim();
      if (!c || !name) throw new Error('اكتب اسم الطالب واختر الشعبة');
      var id = 's' + Utilities.getUuid().slice(0, 8), st = sh_('Students');
      st.getRange(st.getLastRow() + 1, 1, 1, 4).setValues([[id, c.name, name, '']]);
      return {ok: true, student: {id: id, cls: c.id, name: name, note: ''}};
    }
    case 'delStudent': {
      var ssh = sh_('Students');
      rows = readRows_(ssh, 4);
      for (i = 0; i < rows.length; i++) {
        if (String(rows[i][0]) === String(p.sid)) { ssh.deleteRow(i + 2); break; }
      }
      return {ok: true};
    }
    case 'teachers':
      return {ok: true, teachers: teachers_()};
    case 'addTeacher': {
      var tn = String(p.name || '').trim(), tu = String(p.username || '').trim().toLowerCase(), tp = String(p.password || '');
      if (!tn || tu.length < 3) throw new Error('أدخل اسم المعلم واسم مستخدم من 3 أحرف على الأقل');
      if (tp.length < 8) throw new Error('الرقم السري 8 أحرف على الأقل');
      if (tu === 'admin' || findUser_(tu)) throw new Error('اسم المستخدم موجود مسبقًا');
      var us = sh_('Users'), salt = Utilities.getUuid();
      us.getRange(us.getLastRow() + 1, 1, 1, 5).setValues([[tu, tn, salt, hashPw_(tp, salt), 'teacher']]);
      return {ok: true, teachers: teachers_()};
    }
    case 'resetTeacher': {
      var ru = findUser_(String(p.username || '').toLowerCase());
      if (!ru || ru.role !== 'teacher') throw new Error('المعلم غير موجود');
      if (String(p.password || '').length < 8) throw new Error('الرقم السري 8 أحرف على الأقل');
      setPassword_(ru.row, String(p.password));
      return {ok: true};
    }
    case 'delTeacher': {
      var du = findUser_(String(p.username || '').toLowerCase());
      if (du && du.role === 'teacher') sh_('Users').deleteRow(du.row);
      return {ok: true, teachers: teachers_()};
    }
    case 'adminPw': {
      if (String(p.password || '').length < 8) throw new Error('الرقم السري 8 أحرف على الأقل');
      setPassword_(findUser_('admin').row, String(p.password));
      return {ok: true};
    }
    case 'attAll':
      return {ok: true, rows: attAll_(String(p.since || ''))};
    case 'sync':
      return syncRows_(p.rows || [], s.name);
    case 'dailyReport':
      return {ok: true, url: buildDailyReport()};
    case 'drive': {
      var f = DriveApp.createFile('سجل الحضور - ' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd') + '.csv', '\uFEFF' + csvAll_(), MimeType.CSV);
      return {ok: true, url: f.getUrl()};
    }
  }
  throw new Error('طلب غير معروف');
}

/* ---------- الحضور ---------- */
function ensureRows_(cls, date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date))) throw new Error('تاريخ غير صالح');
  var R = roster_();
  var c = R.classes.filter(function (x) { return x.id === cls; })[0];
  if (!c) throw new Error('الشعبة غير موجودة');
  var studs = R.students.filter(function (x) { return x.cls === cls; });
  var at = sh_('Attendance'), last = at.getLastRow(), map = {}, i;
  if (last > 1) {
    var keys = at.getRange(2, 1, last - 1, 1).getValues();
    for (i = 0; i < keys.length; i++) map[keys[i][0]] = i + 2;
  }
  var add = [], next = last + 1;
  studs.forEach(function (s) {
    var k = date + '|' + s.id;
    if (!map[k]) {
      add.push([k, date, c.name, s.name, s.id, '', '', '', '', '', '', '', '', '', '']);
      map[k] = next++;
    }
  });
  if (add.length) at.getRange(last + 1, 1, add.length, 15).setValues(add);
  var out = {}, rows = [];
  studs.forEach(function (s) { var r = map[date + '|' + s.id]; out[s.id] = r; rows.push(r); });
  return {map: out, rows: rows};
}
function stamp_(at, rows, by) {
  var now = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
  at.getRangeList(rows.map(function (r) { return 'N' + r; })).setValue(by);
  at.getRangeList(rows.map(function (r) { return 'O' + r; })).setValue(now);
}
function attFor_(cls) {
  var ids = {};
  roster_().students.forEach(function (s) { if (s.cls === cls) ids[s.id] = 1; });
  var at = sh_('Attendance'), n = at.getLastRow() - 1, out = [];
  if (n < 1) return out;
  at.getRange(2, 1, n, 15).getValues().forEach(function (r) {
    var sid = String(r[4]);
    if (!ids[sid]) return;
    var p = [];
    for (var i = 5; i < 13; i++) p.push(STAT_REV[r[i]] || 'none');
    out.push([fmtDate_(r[1]), sid, p, String(r[13] || '')]);
  });
  return out;
}
/* كل صفوف الحضور (أو منذ تاريخ معيّن) بصيغة مضغوطة: [التاريخ، الطالب، 8 رموز، المعدِّل] */
function attAll_(since) {
  var ids = {}, CODE = {'حاضر': 'p', 'غائب': 'a', 'متأخر': 'l', 'بعذر': 'e'};
  roster_().students.forEach(function (s) { ids[s.id] = 1; });
  var at = sh_('Attendance'), n = at.getLastRow() - 1, out = [];
  if (n < 1) return out;
  at.getRange(2, 1, n, 15).getValues().forEach(function (r) {
    var sid = String(r[4]), d = fmtDate_(r[1]);
    if (!ids[sid] || (since && d < since)) return;
    var c = '';
    for (var i = 5; i < 13; i++) c += CODE[r[i]] || '-';
    out.push([d, sid, c, String(r[13] || '')]);
  });
  return out;
}
/* مزامنة التعديلات المعلّقة من الجوال: كل صف يحمل الحصص التي تغيّرت فقط (null = لم تتغير) */
function syncRows_(rows, by) {
  var groups = {}, lists = {}, stampRows = [], applied = 0, failed = 0, at = sh_('Attendance');
  rows.forEach(function (r) {
    if (r && r.cls && r.date) { var k = r.cls + '|' + r.date; (groups[k] = groups[k] || []).push(r); } else failed++;
  });
  Object.keys(groups).forEach(function (k) {
    var g = groups[k], rm;
    try { rm = ensureRows_(g[0].cls, g[0].date); } catch (e) { failed += g.length; return; }
    g.forEach(function (r) {
      var row = rm.map[r.sid];
      if (!row || !r.p || r.p.length !== 8) { failed++; return; }
      for (var i = 0; i < 8; i++) {
        var v = r.p[i];
        if (v === null || v === undefined) continue;
        var lab = v === 'none' ? '' : STAT[v];
        if (lab === undefined) continue;
        (lists[lab] = lists[lab] || []).push(colL_(P1 + i) + row);
      }
      stampRows.push(row); applied++;
    });
  });
  Object.keys(lists).forEach(function (lab) {
    var rl = at.getRangeList(lists[lab]);
    if (lab === '') rl.clearContent(); else rl.setValue(lab);
  });
  if (stampRows.length) stamp_(at, stampRows, by);
  return {ok: true, applied: applied, failed: failed};
}
function csvAll_() {
  var at = sh_('Attendance'), n = at.getLastRow() - 1, rows = [];
  if (n >= 1) {
    at.getRange(2, 1, n, 15).getValues().forEach(function (r) {
      var has = false, i;
      for (i = 5; i < 13; i++) if (r[i] !== '') has = true;
      if (!has) return;
      var cells = ['"' + String(r[2]).replace(/"/g, '""') + '"', fmtDate_(r[1]), '"' + String(r[3]).replace(/"/g, '""') + '"'];
      for (i = 5; i < 13; i++) cells.push(r[i]);
      rows.push(cells.join(','));
    });
  }
  rows.sort();
  return 'الصف,التاريخ,اسم الطالب,ح1,ح2,ح3,ح4,ح5,ح6,ح7,ح8\n' + rows.join('\n') + '\n';
}

/* ---------- التقارير (صيغ تحسب نفسها تلقائيًا) ---------- */
function onOpen() {
  SpreadsheetApp.getUi().createMenu('نظام الحضور').addItem('تحديث أوراق التقارير', 'buildReports')
    .addItem('تحديث التقرير اليومي', 'buildDailyReport').addToUi();
}
function buildReports() {
  roster_(); // يمنح معرّفات للطلبة الذين أُضيفوا مباشرة في الجدول
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var SR = 'تقرير الطلبة', CR = 'تقرير الشعب', NS = 300, NC = 30, r;
  function fresh(n) {
    var s = ss.getSheetByName(n) || ss.insertSheet(n);
    s.clear(); s.setConditionalFormatRules([]); s.setRightToLeft(true);
    return s;
  }
  function head(s, labels) {
    s.getRange(1, 1, 1, labels.length).setValues([labels]).setFontWeight('bold')
      .setBackground('#1e3a8a').setFontColor('#ffffff').setHorizontalAlignment('center');
    s.setFrozenRows(1);
  }
  function idx(sheet, col) { return 'INDEX(' + sheet + '!$' + col + ':$' + col + ',ROW())'; }
  function cnt(row, status) {
    var p = [];
    for (var c = 0; c < 8; c++) {
      var L = colL_(P1 + c);
      p.push('COUNTIFS(Attendance!$E:$E,$A' + row + ',Attendance!$' + L + ':$' + L + ',"' + status + '")');
    }
    return '=IF($A' + row + '="","",' + p.join('+') + ')';
  }
  function colors(s, col, n) {
    var rg = s.getRange(2, col, n, 1);
    s.setConditionalFormatRules([
      SpreadsheetApp.newConditionalFormatRule().whenNumberLessThan(LOW_ATTENDANCE).setBackground('#fecaca').setRanges([rg]).build(),
      SpreadsheetApp.newConditionalFormatRule().whenNumberGreaterThanOrEqualTo(0.95).setBackground('#bbf7d0').setRanges([rg]).build()
    ]);
  }
  /* ورقة تقرير الطلبة: صف لكل طالب في ورقة Students بنفس الترتيب */
  var s1 = fresh(SR);
  head(s1, ['id', 'الشعبة', 'اسم الطالب', 'حاضر', 'غائب', 'متأخر', 'بعذر', 'الحصص المرصودة', 'نسبة الحضور']);
  var f1 = [];
  for (r = 2; r <= NS + 1; r++) {
    f1.push([
      '=IF(' + idx('Students', 'A') + '="","",' + idx('Students', 'A') + ')',
      '=IF($A' + r + '="","",' + idx('Students', 'B') + ')',
      '=IF($A' + r + '="","",' + idx('Students', 'C') + ')',
      cnt(r, STAT.present), cnt(r, STAT.absent), cnt(r, STAT.late), cnt(r, STAT.excused),
      '=IF($A' + r + '="","",SUM(D' + r + ':G' + r + '))',
      '=IF(OR($A' + r + '="",H' + r + '=0),"",D' + r + '/H' + r + ')'
    ]);
  }
  s1.getRange(2, 1, NS, 9).setFormulas(f1);
  s1.getRange(2, 9, NS, 1).setNumberFormat('0.0%');
  s1.setColumnWidth(2, 120); s1.setColumnWidth(3, 260);
  s1.hideColumns(1);
  colors(s1, 9, NS);
  /* ورقة تقرير الشعب: صف لكل شعبة في ورقة Classes */
  var s2 = fresh(CR);
  head(s2, ['الشعبة', 'عدد الطلبة', 'حاضر', 'غائب', 'متأخر', 'بعذر', 'الحصص المرصودة', 'نسبة الحضور']);
  var f2 = [];
  for (r = 2; r <= NC + 1; r++) {
    var row = [
      '=IF(' + idx('Classes', 'B') + '="","",' + idx('Classes', 'B') + ')',
      '=IF($A' + r + '="","",COUNTIF(Students!$B:$B,$A' + r + '))'
    ];
    ['D', 'E', 'F', 'G'].forEach(function (L) {
      row.push('=IF($A' + r + '="","",SUMIFS(\'' + SR + '\'!$' + L + ':$' + L + ',\'' + SR + '\'!$B:$B,$A' + r + '))');
    });
    row.push('=IF($A' + r + '="","",SUM(C' + r + ':F' + r + '))');
    row.push('=IF(OR($A' + r + '="",G' + r + '=0),"",C' + r + '/G' + r + ')');
    f2.push(row);
  }
  s2.getRange(2, 1, NC, 8).setFormulas(f2);
  s2.getRange(2, 8, NC, 1).setNumberFormat('0.0%');
  s2.setColumnWidth(1, 160);
  colors(s2, 8, NC);
  Logger.log('تم إنشاء ورقتي تقرير الطلبة وتقرير الشعب وهما تتحدثان تلقائيًا.');
}

/* ---------- التقرير اليومي: نسبة الحضور لكل شعبة في كل تاريخ ---------- */
function buildDailyReport() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var classes = [];
  readRows_(sh_('Classes'), 2).forEach(function (r) { if (r[1]) classes.push(String(r[1])); });
  var at = sh_('Attendance'), n = at.getLastRow() - 1, agg = {};
  if (n >= 1) {
    at.getRange(2, 1, n, 15).getValues().forEach(function (r) {
      var d = fmtDate_(r[1]), c = String(r[2]);
      if (!d || classes.indexOf(c) < 0) return;
      var a = agg[d] = agg[d] || {};
      var x = a[c] = a[c] || {p: 0, t: 0, a: 0};
      for (var i = 5; i < 13; i++) {
        if (r[i] === '') continue;
        x.t++;
        if (r[i] === STAT.present) x.p++;
        else if (r[i] === STAT.absent) x.a++;
      }
    });
  }
  var dates = Object.keys(agg).filter(function (d) {
    return classes.some(function (c) { return agg[d][c] && agg[d][c].t > 0; });
  }).sort().reverse();
  var rows = dates.map(function (d) {
    var p = 0, t = 0, ab = 0, line = [d];
    classes.forEach(function (c) {
      var x = agg[d][c];
      if (x && x.t) { line.push(x.p / x.t); p += x.p; t += x.t; ab += x.a; } else line.push('');
    });
    line.push(t ? p / t : '');
    line.push(ab);
    return line;
  });
  var s = ss.getSheetByName('تقرير الأيام') || ss.insertSheet('تقرير الأيام');
  s.clear(); s.setConditionalFormatRules([]); s.setRightToLeft(true);
  var head = ['التاريخ'].concat(classes, ['الإجمالي', 'حصص الغياب']);
  s.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold')
    .setBackground('#1e3a8a').setFontColor('#ffffff').setHorizontalAlignment('center');
  s.setFrozenRows(1); s.setFrozenColumns(1);
  if (rows.length) {
    s.getRange(2, 1, rows.length, 1).setNumberFormat('@');
    s.getRange(2, 1, rows.length, head.length).setValues(rows);
    var rg = s.getRange(2, 2, rows.length, classes.length + 1);
    rg.setNumberFormat('0.0%');
    s.setConditionalFormatRules([
      SpreadsheetApp.newConditionalFormatRule().whenNumberLessThan(LOW_ATTENDANCE).setBackground('#fecaca').setRanges([rg]).build(),
      SpreadsheetApp.newConditionalFormatRule().whenNumberGreaterThanOrEqualTo(0.95).setBackground('#bbf7d0').setRanges([rg]).build()
    ]);
  }
  s.setColumnWidth(1, 110);
  return ss.getUrl() + '#gid=' + s.getSheetId();
}
/* شغّلها مرة واحدة ليتحدّث التقرير اليومي تلقائيًا كل ساعة */
function installReportTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'buildDailyReport') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('buildDailyReport').timeBased().everyHours(1).create();
  Logger.log('سيتحدّث التقرير اليومي كل ساعة.');
}

/* ---------- بيانات القوائم الأولية (تُستخدم مرة واحدة عند الإعداد) ---------- */
var SEED = {"classes": [{"id": "c0", "name": "عاشر أ", "students": [{"id": "s1", "name": "البراء هلال زاهر التوبي", "note": ""}, {"id": "s2", "name": "الوارث حميد مسعود اليحيائي", "note": ""}, {"id": "s3", "name": "الوارث سعود سالم البرواني", "note": ""}, {"id": "s4", "name": "الوليد خالد خميس اليعقوبي", "note": ""}, {"id": "s5", "name": "تركي فيصل محمد المحروقي", "note": ""}, {"id": "s6", "name": "جواد سعود مسعود السليمي", "note": ""}, {"id": "s7", "name": "حمزة حافظ خميس البوسعيدي", "note": ""}, {"id": "s8", "name": "سليمان يعقوب حمد البوسعيدي", "note": ""}, {"id": "s9", "name": "شهاب هويشل خليف الناصري", "note": ""}, {"id": "s10", "name": "عبدالرحمن عثمان سعيد العبري", "note": ""}, {"id": "s11", "name": "عبدالله بدر حمود التوبي", "note": ""}, {"id": "s12", "name": "عبدالله عامر علي القصابي", "note": ""}, {"id": "s13", "name": "عبدالله محمد عبدالله اليحيائي", "note": ""}, {"id": "s14", "name": "عمر حسن ناصر الهنائي", "note": ""}, {"id": "s15", "name": "عمر عبدالكريم محمد الشماخي", "note": ""}, {"id": "s16", "name": "فراس حمد محمد التوبي", "note": ""}, {"id": "s17", "name": "كهلان سليمان عبدالله الريامي", "note": ""}, {"id": "s18", "name": "محمد خالد محمد العلوي", "note": ""}, {"id": "s19", "name": "محمد وليد حمد الشوكري", "note": "احتياط 15 / 9"}, {"id": "s20", "name": "محمد يوسف احمد المحروقي", "note": ""}, {"id": "s21", "name": "محمود عبدالعزيز درويش الشعيلي", "note": ""}, {"id": "s22", "name": "مصعب أحمد محمد الشعيلي", "note": ""}, {"id": "s23", "name": "منذر بن محمد بن صالح الجابري", "note": "احتياط 9 / 9"}, {"id": "s24", "name": "يزن مصطفى سعيد الصبحي", "note": ""}, {"id": "s25", "name": "يوسف بن ناصر بن محمد العبري", "note": "احتياط 13 / 9"}]}, {"id": "c1", "name": "عاشر ب", "students": [{"id": "s26", "name": "ابراهيم ناصر سعيد الوردي", "note": ""}, {"id": "s27", "name": "الحسام هلال علي العدوي", "note": ""}, {"id": "s28", "name": "الحواري محمد حميد الهنائي", "note": ""}, {"id": "s29", "name": "الكنان يقظان حمد الشقصي", "note": ""}, {"id": "s30", "name": "بدر بن مالك بن راشد المحروقي", "note": "احتياط 9 / 9"}, {"id": "s31", "name": "خالد سعيد مطر الصباري", "note": ""}, {"id": "s32", "name": "راشد عبدالله راشد المعمري", "note": ""}, {"id": "s33", "name": "راشد محمد سالم التوبي", "note": ""}, {"id": "s34", "name": "سالم عبدالرحمن سالم المزيدي", "note": ""}, {"id": "s35", "name": "سيف سلطان سيف المقبالي", "note": ""}, {"id": "s36", "name": "صالح سالم صالح التوبي", "note": ""}, {"id": "s37", "name": "عبدالله علي عبدالله المنذري", "note": ""}, {"id": "s38", "name": "عبدالله وليد عبدالله المحروقي", "note": ""}, {"id": "s39", "name": "علي بن سلطان بن ناصر العبري", "note": "احتياط 27 / 9"}, {"id": "s40", "name": "عمران عاهد سعيد الغافري", "note": ""}, {"id": "s41", "name": "محمد حمد سليـّم الهطالي", "note": ""}, {"id": "s42", "name": "محمد خلفان عبيد الشوكري", "note": ""}, {"id": "s43", "name": "محمد سلطان سيف الصارخي", "note": ""}, {"id": "s44", "name": "ناصر عمير ناصر الريامي", "note": ""}, {"id": "s45", "name": "نايف مصبح سليمان البلوشي", "note": ""}, {"id": "s46", "name": "نبراس موسى قصور الحجي", "note": ""}, {"id": "s47", "name": "هود علي محمد الريامي", "note": ""}, {"id": "s48", "name": "وسام أحمد سعيد العبري", "note": ""}, {"id": "s49", "name": "يحيى عامر سيف الهنائي", "note": ""}, {"id": "s50", "name": "يوسف عبدالله محمد العبري", "note": "احتياط 20 / 9"}]}, {"id": "c2", "name": "حادي عشر أ", "students": [{"id": "s51", "name": "اليمان بن ناصر بن سعيد الشملي", "note": ""}, {"id": "s52", "name": "المقداد بن حمدان بن حمد العلوي", "note": ""}, {"id": "s53", "name": "أحمد بن حمد بن محمد الرواحي", "note": ""}, {"id": "s54", "name": "أحمد بن عادل بن دويله الهنائي", "note": ""}, {"id": "s55", "name": "أنس بن سلام بن ذياب الجديدي", "note": ""}, {"id": "s56", "name": "أواب بن داود بن خصيب الجابري", "note": ""}, {"id": "s57", "name": "حمدان بن عبدالله بن حمدان الرواحي", "note": ""}, {"id": "s58", "name": "راشد بن سلطان بن زاهر العبري", "note": ""}, {"id": "s59", "name": "رياض بن ياسر بن حمود الرميضي", "note": ""}, {"id": "s60", "name": "سالم بن حمد بن سالم المقرشي", "note": ""}, {"id": "s61", "name": "سعود بن سعيد بن سعود العبري", "note": ""}, {"id": "s62", "name": "عبدالرؤوف بن محمد بن سعيد العميري", "note": ""}, {"id": "s63", "name": "عبدالله بن حمد بن محمد الربخي", "note": ""}, {"id": "s64", "name": "عبدالله بن فهد بن محمد العامري", "note": ""}, {"id": "s65", "name": "محمد بن خالد بن محمد المقبالي", "note": ""}, {"id": "s66", "name": "محمد بن سيف بن حبيب التوبي", "note": ""}, {"id": "s67", "name": "محمد بن عبدالله بن أحمد اليحيائي", "note": ""}, {"id": "s68", "name": "محمد بن عبدالله بن عوض العبري", "note": ""}, {"id": "s69", "name": "مروان بن عادل بن يحيى المحروقي", "note": ""}, {"id": "s70", "name": "معاذ بن عبدالله السو الريامي", "note": ""}, {"id": "s71", "name": "منصور بن علي بن منصور الدرمكي", "note": ""}, {"id": "s72", "name": "نايف بن فهد بن عبدالله الشندودي", "note": ""}, {"id": "s73", "name": "وائل بن خالد بن خليفة الناصري", "note": ""}]}, {"id": "c3", "name": "حادي عشر ب", "students": [{"id": "s74", "name": "الأيهم بن أحمد بن جمعة التوبي", "note": ""}, {"id": "s75", "name": "الخليل بن احمد بن زهران العمري", "note": ""}, {"id": "s76", "name": "القيس بن محمد بن سليمان العبري", "note": "منقول من وزارة التعليم"}, {"id": "s77", "name": "المختار بن صالح بن محمد الشعيلي", "note": ""}, {"id": "s78", "name": "المقدام بن هلال بن علي العدوي", "note": ""}, {"id": "s79", "name": "اليسع بن عبدالعزيز بن محمد التوبي", "note": ""}, {"id": "s80", "name": "أسامة بن محمد بن علي الهاشمي", "note": "منقول من وزارة التعليم"}, {"id": "s81", "name": "جابر بن زيد بن سالم الكلباني", "note": ""}, {"id": "s82", "name": "حمد بن حمود بن سالم الرواحي", "note": ""}, {"id": "s83", "name": "المهند بن حسن بن علي العميري", "note": "أُضيف بتاريخ 2026-09-20"}, {"id": "s84", "name": "صهيب بن سيف بن عبدالله الذهلي", "note": "منقول من وزارة التعليم"}, {"id": "s85", "name": "عبدالرحمن بن بدر بن سالم المغيري", "note": ""}, {"id": "s86", "name": "عبدالرحمن بن سامي بن علي الكندي", "note": ""}, {"id": "s87", "name": "عبدالله بن موسى بن عبدالله القصابي", "note": ""}, {"id": "s88", "name": "عزالدين بن ناصر بن سالم الشماخي", "note": ""}, {"id": "s89", "name": "عمار بن ناصر بن علي الحضرمي", "note": ""}, {"id": "s90", "name": "ماجد بن فهمي بن سلام المحروقي", "note": ""}, {"id": "s91", "name": "محمد بن أحمد بن سالم المحروقي", "note": ""}, {"id": "s92", "name": "يوسف بن سيف بن ناصر الهنائي", "note": "منقول من وزارة التعليم"}, {"id": "s93", "name": "يونس بن أنور بن ربيع الجامودي", "note": ""}]}, {"id": "c4", "name": "ثاني عشر", "students": [{"id": "s94", "name": "المنذر بن سالم بن سليمان المحروقي", "note": ""}, {"id": "s95", "name": "أحمد بن حمد بن سعود الشعيلي", "note": ""}, {"id": "s96", "name": "أحمد بن سليمان بن محمد العلوي", "note": ""}, {"id": "s97", "name": "حمد بن محمود بن علي الصبحي", "note": ""}, {"id": "s98", "name": "زاهر بن سعيد بن زاهر العبري", "note": ""}, {"id": "s99", "name": "سعيد بن مسعود بن راشد الكلباني", "note": ""}, {"id": "s100", "name": "سيف بن عبدالله بن محمد السليماني", "note": ""}, {"id": "s101", "name": "طالب بن عبدالله بن سعيد الهنائي", "note": ""}, {"id": "s102", "name": "عامر بن خلفان بن عامر الحضرمي", "note": ""}, {"id": "s103", "name": "عبدالرحمن بن عيسى بن سالم المقبالي", "note": ""}, {"id": "s104", "name": "عبدالله بن حمد بن عبدالله الحديدي", "note": ""}, {"id": "s105", "name": "عمار بن عبدالله بن محمد المحروقي", "note": ""}, {"id": "s106", "name": "مازن بن أحمد بن يحيى الوردي", "note": ""}, {"id": "s107", "name": "محمود بن حمود بن محمد التوبي", "note": ""}, {"id": "s108", "name": "مصطفى بن خميس بن حمدون الراشدي", "note": ""}, {"id": "s109", "name": "معضد بن عبدالله بن علي الفارسي", "note": ""}]}]};
